<!-- Footer section -->
	<footer class="footer-section">
		<div class="container footer-top">
			<div class="row">
				<!-- widget -->
				<div class="col-sm-6 col-lg-4 footer-widget">
                <h6 class="fw-title">Burdwan Holychild School</h6>
					<div class="about-widget">
						<img src="img/logo2.png" alt="">
						<!--<p>Khanpukur, Kalna Road, Burdwan<br>
E-mail : holychildschool.burdwan@gmail.com<br>
Phone: 0342 – 2624248 (Office)</p>-->

					</div>
				</div>
				<!-- widget -->
				<div class="col-sm-6 col-lg-4 footer-widget">
					<h6 class="fw-title">USEFUL LINK</h6>
					<div class="dobule-link">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="about.php">About us</a></li>
							<li><a href="academic.php">Academic</a></li>
							<li><a href="facilities.php">Features</a></li>
							<li><a href="our-staff.php">Our Staff</a></li>
						</ul>
						<ul>
							<li><a href="gallery.php">Event Gallery</a></li>
							<li><a href="alumni.php">Alumni</a></li>
							<li><a href="">Contact Us</a></li>
							
						</ul>
					</div>
				</div>
				
                
				<div class="col-sm-6 col-lg-4 footer-widget">
					<h6 class="fw-title">CONTACT</h6>
					<ul class="contact">
						<li><p><i class="fa fa-map-marker"></i> KHANPUKUR, KALNA ROAD, BURDWAN</p></li>
						<li><p><i class="fa fa-phone"></i> (0342) – 2624248</p></li>
						<li><p><i class="fa fa-envelope"></i> holychildschool.burdwan@gmail.com
</p></li>
						<li><p><i class="fa fa-clock-o"></i> Monday - Friday, 08:00AM - 06:00 PM</p></li>
					</ul>
				</div>
			</div>
		</div>
		<!-- copyright -->
		<div class="copyright">
			<div class="container">
				<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Burdwan Holichaild School, designed by <a href="https://technofav.in" target="_blank">technofav</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
			</div>		
		</div>
	</footer>
	<!-- Footer section end-->