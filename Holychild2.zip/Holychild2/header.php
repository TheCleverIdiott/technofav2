<!-- header section -->
	<header class="header-section">
		<div class="container">
			<!-- logo -->
			<a href="index.php" class="site-logo"><img src="img/logo.png" class="img-responsive"  alt=""></a>
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<div class="header-info">
								<div class="hf-item">
					<button type="button" class="btn blink-button" data-toggle="modal" data-target="#myModal">Click Admission Query</button>
				</div>
			</div>
		</div>
	</header>
	<!-- header section end-->


	<!-- Header section  -->
	<nav class="nav-section">
		<div class="container">
			<div class="nav-right">
				<a href="tel:03422624248"><i class="fa fa-search"></i> Helpline - (0342) – 2624248</a>
				
			</div>
			<ul class="main-menu">
				<li <?php if($page =="home"){?> class="active menu__item menu__item--current" <?php } ?>><a href="index.php">Home</a></li>
				<li <?php if($page =="about"){?> class="active menu__item menu__item--current" <?php } ?>><a href="about.php">About Us</a></li>
				<li <?php if($page =="academic"){?> class="active menu__item menu__item--current" <?php } ?>><a href="academic.php">Academic</a></li>
				<li <?php if($page =="facilities"){?> class="active menu__item menu__item--current" <?php } ?>><a href="facilities.php">Facilities</a></li>
				<li <?php if($page =="staff"){?> class="active menu__item menu__item--current" <?php } ?>><a href="our-staff.php">Our Staff</a></li>
				<li <?php if($page =="gallery"){?> class="active menu__item menu__item--current" <?php } ?>><a href="gallery.php">Event Gallery</a></li>
                <li <?php if($page =="alumni"){?> class="active menu__item menu__item--current" <?php } ?>><a href="alumni.php">Alumni</a></li>
                <li <?php if($page =="contact"){?> class="active menu__item menu__item--current" <?php } ?>><a href="contact.php">Contact Us</a></li>
			</ul>
		</div>
	</nav>
	<!-- Header section end -->