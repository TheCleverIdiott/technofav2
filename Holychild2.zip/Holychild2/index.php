<?php 
ob_start();
error_reporting(0);
$page = "home";
include"conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Burdwan Holichild School</title>
	<meta charset="UTF-8">
	<meta name="description" content="Unica University Template">
	<meta name="keywords" content="event, unica, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.png" rel="shortcut icon"/>
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/themify-icons.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
<link href="css/lightbox.css" rel="stylesheet" type="text/css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<?php include "header.php"; ?>


	<!-- Hero section -->
	<section class="hero-section">
		<div class="hero-slider owl-carousel">
			<div class="hs-item set-bg" data-setbg="img/hero-slider/1.jpg"></div>
            <div class="hs-item set-bg" data-setbg="img/hero-slider/2.jpg"></div>
            <div class="hs-item set-bg" data-setbg="img/hero-slider/3.jpg"></div>
            <div class="hs-item set-bg" data-setbg="img/hero-slider/4.jpg"></div>
            <div class="hs-item set-bg" data-setbg="img/hero-slider/5.jpg"></div>
		</div>
	</section>
    
    
    
	<!-- Hero section end -->


	<!-- Notice  -->
<!-- 	<section class="counter-section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12 col-md-6">
					<marquee behavior="alternate" hight="20" scrollamount="05" style="font-size:20px; color:#fff; letter-spacing:1px;">Admission Going On from Nursery to Class IX</marquee>
				</div>
				
                
			</div>
		</div>
	</section> -->
	<?php include "scroll-notice.php"; ?>
	<!-- Notice -->


	<!-- Services section -->
	<section class="service-section spad">
		<div class="container services">
			<div class="section-title text-center">
				<h3>About The School</h3>
				<p>Opportunities are the launch pads, which propel a person towards greater heights of success. By providing opportunities that promote social, emotional, cultural, mental and physical growth, we at Burdwan Holy Child School strive to enhance our students' potential and personality into one of an all-rounded individual, a contributing member to society and the nation at large.</p>
			</div>
			<div class="row">
				
                <div class="col-lg-4 col-sm-6 service-item">
					<div class="box-1">
                    <div class="service-icon">
						<img src="img/services-icons/1.png" alt="1">
					</div>
					<div class="service-content">
						<h4>Early Years</h4>
						<p>It caters to the specific needs of young learners in a safe and nurturing family environment, within the larger canvas.</p>
					</div>
				</div>
                </div>
                
				
                <div class="col-lg-4 col-sm-6 service-item">
                <div class="box-2">
					<div class="service-icon">
						<img src="img/services-icons/2.png" alt="1">
					</div>
					<div class="service-content">
						<h4>Elementary School</h4>
						<p>We facilitate an atmosphere and ambience that celebrates these differences and backgrounds in a warm and nurturing environment.</p>
					</div>
				</div>
                </div>
                
				<div class="col-lg-4 col-sm-6 service-item">
                <div class="box-3">
					<div class="service-icon">
						<img src="img/services-icons/3.png" alt="1">
					</div>
					<div class="service-content">
						<h4>Middle School</h4>
						<p>It serves as a bridge between Elementary School and High School and has a long-term impact on a student's readiness for future</p>
					</div>
				</div>
                </div>
                
                
				<div class="col-lg-4 col-sm-6 service-item">
                <div class="box-4">
					<div class="service-icon">
						<img src="img/services-icons/4.png" alt="1">
					</div>
					<div class="service-content">
						<h4>High School</h4>
						<p>There is a constant effort to uphold, inculcate, and nurture values and principles that foster holistic development in our students.</p>
					</div>
				</div>
                </div>
                
                
				<div class="col-lg-4 col-sm-6 service-item">
                <div class="box-5">
					<div class="service-icon">
						<img src="img/services-icons/5.png" alt="1">
					</div>
					<div class="service-content">
						<h4>Curriculum & Exams</h4>
						<p>Prepare students for life by enabling them to develop an informed curiosity and a lasting passion for learning.</p>
					</div>
				</div>
                </div>
                
				<div class="col-lg-4 col-sm-6 service-item">
                <div class="box-6">
					<div class="service-icon">
						<img src="img/services-icons/6.png" alt="1">
					</div>
					<div class="service-content">
						<h4>Activity Hub</h4>
						<p>Children need a platform to unleash their creativity, to understand and appreciate Indian and Global culture and preserve it...</p>
					</div>
				</div>
                </div>
                
                
			</div>
		</div>
	</section>
	<!-- Services section end -->

	
	<!-- Enroll section -->
	<section class="enroll-section spad set-bg" data-setbg="img/enroll-bg.jpg">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="section-title text-white">
						<h3>Co-Curricular</h3>
						<p>Get started with us to explore the exciting</p>
					</div>
					<div class="enroll-list text-white">
						<div class="enroll-list-item">
							<span>1</span>
							<h5>Visual Arts</h5>
							<p>A wide range of courses are offered in the performing arts</p>
						</div>
						<div class="enroll-list-item">
							<span>2</span>
							<h5>Adventure & Field Trip</h5>
							<p>Students are given opportunity to participate Adventure Trip..</p>
						</div>
						<div class="enroll-list-item">
							<span>3</span>
							<h5>Safety & Secrity</h5>
							<p>A reliable security system with professional security personnel, a completely fenced campus</p>
						</div>
					</div>
				</div>
                
                
				<div class="col-lg-6">
					<div class="section-title text-white">
						<h3>&nbsp;</h3>
						<p>&nbsp;</p>
					</div>
					<div class="enroll-list text-white">
						<div class="enroll-list-item">
							<span>4</span>
							<h5>SPORTS</h5>
							<p>Champions are made from something they have deep inside of them</p>
						</div>
						<div class="enroll-list-item">
							<span>5</span>
							<h5>Music</h5>
							<p>Children can make beautiful music is less significant..</p>
						</div>
						<div class="enroll-list-item">
							<span>6</span>
							<h5>Experiential learning</h5>
							<p>Teach me and I remember. Involve me and I learn</p>
						</div>
					</div>
				</div>
                
                
                
			</div>
            
		</div>
	</section>
	<!-- Enroll section end -->


	<!-- Courses section -->
	<section class="courses-section spad2">
		<div class="container">
			<div class="section-title text-center">
				<h3 style="color: #020031">Recent Event Gallery</h3>
				<p>Building a better world, one course at a time</p>
			</div>
			<div class="row">
				
                
		
			
			
		
	
                
                <div class="gallery-section">
                <div class="gallery">
                	<?php  
                	$folder_image=mysqli_query($con,"select * from `folder_image` order by id desc LIMIT 6");
               		while($row=mysqli_fetch_array($folder_image))
                    {                     
                     
                      ?>   
                
                    <!-- course item -->
                    <div class="col-lg-4 col-md-6 course-item">
                    <a class="example-image-link" href="gallery2.php?value=<?php echo $row[id]; ?>" data-title="">
                    <img src="<?php echo $row[file]; ?>" class="img-responsive"><br>
                    </a>
                    </div>
                    <!-- course item -->
                    <?php
                     } ?>
                    
                    <!-- course item -->
                    <!-- <div class="col-lg-4 col-md-6 course-item">
                    <a class="example-image-link" href="img/gallery/2.jpg" data-lightbox="example-set" data-title="">
                    <img src="img/gallery/2.jpg" class="img-responsive"><br>
                    </a>
                    </div> -->
                    <!-- course item -->
                    
                    
                    <!-- course item -->
                    <!-- <div class="col-lg-4 col-md-6 course-item">
                    <a class="example-image-link" href="img/gallery/3.jpg" data-lightbox="example-set" data-title="">
                    <img src="img/gallery/3.jpg" class="img-responsive"><br>
                    </a>
                    </div> -->
                    <!-- course item -->
                
               
                
                
                	<!-- course item -->
                    <!-- <div class="col-lg-4 col-md-6 course-item">
                    <a class="example-image-link" href="img/gallery/3.jpg" data-lightbox="example-set" data-title="">
                    <img src="img/gallery/3.jpg" class="img-responsive"><br>
                    </a>
                    </div> -->
                    <!-- course item -->
                    
                    <!-- course item -->
                    <!-- <div class="col-lg-4 col-md-6 course-item">
                    <a class="example-image-link" href="img/gallery/1.jpg" data-lightbox="example-set" data-title="">
                    <img src="img/gallery/1.jpg" class="img-responsive"><br>
                    </a>
                    </div> -->
                    <!-- course item -->
                    
                    
                    <!-- course item -->
                    <!-- <div class="col-lg-4 col-md-6 course-item">
                    <a class="example-image-link" href="img/gallery/2.jpg" data-lightbox="example-set" data-title="">
                    <img src="img/gallery/2.jpg" class="img-responsive"><br>
                    </a>
                    </div> -->
                    <!-- course item -->
                
                
                
                
				
                </div>
				</div>
                
                
                
                
                
			</div>
		</div>
	</section>
	<!-- Courses section end-->


	<!-- Fact section -->
	<section class="fact-section spad set-bg" data-setbg="img/fact-bg.jpg">
		<div class="container">
			<h4>First Day at School!</h4>
            <h3>ARE YOU READY ?</h3>
            <p>Opportunities are the launch pads, which propel a person towards greater heights of success. By providing opportunities that promote social, emotional, cultural, mental and physical growth, we at Burdwan Holy Child School strive to enhance our students' potential and personality into one of an all-rounded individual, a contributing member to society and the nation at large.</p>
		</div>
	</section>
	<!-- Fact section end-->



<!--OnlineQuery-->
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div> 
 <!--OnlineQuery-->
<!-- Modal --> 


<?php include "footer.php"; ?>


	
<script src="js/lightbox-plus-jquery.min.js"> </script>

	<!--====== Javascripts & Jquery ======-->

	<script src="js/owl.carousel.min.js"></script>
	
	<script src="js/main.js"></script>
    
    
  
    
	
</body>
</html>